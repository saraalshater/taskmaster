package com.example.taskmaster;

public class Task {
    public String title;
    public String body;
    public String status;

    public Task(String title, String body, String status) {
        this.title = title;
        this.body = body;
        this.status = status;
    }
}
